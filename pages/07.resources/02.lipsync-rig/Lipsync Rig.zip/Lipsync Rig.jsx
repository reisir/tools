{
  // Configuration
  var mouthOptions = 3;
  var checkboxName = "Edit mode";
  var dropdownName = "Mouth";
  var dropdownOptions = ["Closed", "Half", "Open"];

  // Time (in seconds) between markers
  var markerSpacing = 0.15;

  function rig() {
    var active = app.project.activeItem;
    var selectedLayers = active.selectedLayers;

    if (!selectedLayers || !selectedLayers.length)
      return alert("No selected layer(s)");

    for (var i = 0; i < selectedLayers.length; i++) {
      var layer = selectedLayers[i];
      if (layer.canSetTimeRemapEnabled) {
        layer.timeRemapEnabled = true;
        layer.timeRemap.expression = timeRemapExpression();
        addCheckbox(layer);
        addDropdown(layer);
        addMarkers(layer);
      }
    }
  }

  // Helper functions
  function addCheckbox(layer) {
    var effects = layer.Effects;
    if (effects(checkboxName)) return;

    var checkbox = effects.addProperty("ADBE Checkbox Control");
    checkbox.name = checkboxName;
    checkbox.checkbox.setValue(true);
  }

  function addDropdown(layer) {
    var effects = layer.Effects;
    if (effects(dropdownName)) return;

    // Dropdown control is a special case
    // https://creativecow.net/forums/thread/extendscript-naming-dropdown-menu-effect/
    var emptyDropdown = effects.addProperty("ADBE Dropdown Control");
    var dropdown = emptyDropdown.menu.setPropertyParameters(dropdownOptions);
    dropdown.propertyGroup(1).name = dropdownName;
  }

  function addMarkers(layer) {
    // Function to check if the marker already exists.
    // Uses try / catch because keyTime() throws an error when it doesn't find anything
    function markerExists(layer, comment) {
      comment = comment.toString();
      try {
        layer.marker.keyTime(comment);
        return true;
      } catch (error) {
        return false;
      }
    }

    // Add all missing markers
    for (var i = 0; i < mouthOptions; i++) {
      if (markerExists(layer, i + 1)) continue;
      var marker = new MarkerValue(i + 1);
      var time = markerSpacing * i + layer.inPoint;
      layer.marker.setValueAtTime(time, marker);
    }
  }

  function timeRemapExpression() {
    return '// Get the composition displayStartTime if this layer is a comp\nconst compFix = source.className === "Comp" ? source.displayStartTime : 0;\n\n// Get edit mode switch setting\nconst mode = effect("Edit mode")("Checkbox").value;\n\n// which mouth should be displayed\nconst which = effect("Mouth")("Menu").value.toString();\n\n// Catch missing marker errors\ntry {\n\t// Get selected mouth frame time\n\tconst where = thisLayer.sourceTime(0) + marker.key(which).time - compFix;\n\t// Return original frame or selected mouth\n\tmode ? value : where;\n} catch (error) {\n\tif (!mode) throw Error(`Marker "${which}" not found, can\'t display selected mouth\'`);\n\tvalue;\n}';
  }

  // Call script
  rig();
}
